#pragma once

#ifdef __cplusplus
#include "translator.hpp"
#else
#include "translator_capi.h"
#endif
